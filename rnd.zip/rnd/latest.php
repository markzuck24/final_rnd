<!DOCTYPE html> 
<html> 
	
<head> 
	<title> 
		How to call PHP function 
		on the click of a Button ? 
	</title> 
</head> 

<!-- <body style="text-align:center;">  -->
<body>
<div class="row">
        <div class="column">
            <h1>The textarea readonly attribute</h1>

            <textarea rows="20" cols="70">
            At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies.
            </textarea>

        </div>
        <div class="column">
            <h1>The textarea readonly attribute</h1>

            <textarea rows="20" cols="70" readonly>
            At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies.
            </textarea>

        </div>
    </div>
	
	<h1 style="color:green;"> 
		GeeksforGeeks 
	</h1> 
	
	<h4> 
		How to call PHP function 
		on the click of a Button ? 
	</h4> 
	
	<?php
		if(array_key_exists('button1', $_POST)) { 
			button1(); 
		} 
		else if(array_key_exists('button2', $_POST)) { 
			button2(); 
		} 
		function button1() { 
			$command = escapeshellcmd('python /var/www/html/rnd/latest.py');
            $output = shell_exec($command);
            // echo "<script>  alert('hi') </script>" ;
            echo "hi";
		} 
		function button2() { 
			echo "This is Button2 that is selected"; 
		} 
	?> 

	<form method="post"> 
		<input type="submit" name="button1"
				class="button" value="Button1" /> 
		
		<input type="submit" name="button2"
				class="button" value="Button2" /> 
	</form> 
</head> 

</html> 
