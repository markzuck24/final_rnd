from selenium.common.exceptions import TimeoutException
from selenium import webdriver 
#from selenium.webdriver import ActionChains
from selenium.webdriver.remote.webelement import WebElement 
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    
from selenium.webdriver.common.keys import Keys
import time
#from urllib import urlopen,urlretrieve
#from bs4 import BeautifulSoup ,re
#from urllib import urlopen
#from bs4 import BeautifulSoup ,re
#directory = "/home/satyam/Desktop/MJ_training/Aditya_scrapper/output"
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--disable-extensions')
chrome_options.add_argument('--profile-directory=Default')
chrome_options.add_argument("--incognito")
chrome_options.add_argument("--disable-plugins-discovery");
chrome_options.add_argument("--start-maximized")
driver = webdriver.Chrome(r"/var/www/html/rnd/aditya/Aditya/chromedriver",chrome_options=chrome_options)
driver.delete_all_cookies()
driver.set_window_size(800,800)
driver.set_window_position(0,0)
print('arguments done')
driver.get("https://quillbot.com/")

inputFile = open('/var/www/html/rnd/h1.txt', 'r')
outputFile = open("/var/www/html/rnd/p1.txt", "a")
data= inputFile.read().strip() 
array= []
splat = data.split("\n\n")
#len(splat)
for string_i in splat:
    while True:
        try:
            inputBox= WebDriverWait(driver, 15).until(EC.visibility_of_element_located((By.CSS_SELECTOR, "div#inputText")))
            inputBox.clear()                                   
            inputBox.send_keys(string_i)
            submit= WebDriverWait(driver,10 ).until(EC.visibility_of_element_located((By.CSS_SELECTOR, "div#inOutContainer div.Pane.vertical.Pane1 > div > div > div:nth-child(2) > div > div > div > div > div:nth-child(2) > div > div > div > button[type='button']")))
#            print(submit.text)               
    #        hover = ActionChains(driver).move_to_element(submit)
    #        hover.perform()
            submit.click()
#            print(submit.value_of_css_property('opacity'))
            
            time.sleep(0.6)
            while(submit.value_of_css_property('opacity')!='1'):
    #            print(submit.text)               
    #            print(submit.value_of_css_property('opacity'))
                time.sleep(0.2)
    #            print("waiting")
            outputBox=WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CSS_SELECTOR, "div#outputText > div.MuiGrid-root.MuiGrid-item.MuiGrid-grid-xs-true")))
            paraphrase=outputBox.text
            print(paraphrase)
            outputFile.write(paraphrase+"\n\n")

    #        progressBar=WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CSS_SELECTOR, "div#outputBottomQuillControls-default div > div > div:nth-child(1)")))
            break
        except Exception as e:
            print("exception occured",e)
            popupBox=driver.find_elements_by_css_selector("div.MuiPaper-root.MuiDialog-paper.jss396.MuiDialog-paperScrollPaper.MuiDialog-paperWidthMd.MuiPaper-elevation24.MuiPaper-rounded")
            if len(popupBox)!=0 :
               closeButton=popupBox[0].find_element_by_tag_name("button")
               closeButton.click()
               print("Popup box was there and is removed");
            else :
                loginBox=driver.find_elements_by_css_selector("button.MuiButtonBase-root.MuiIconButton-root.auth-close-btn")
                if(len(loginBox)!=0):
                    loginBox[0].click()
                else:
                    print("Unhandled stopping")
                    break
inputFile.close()
outputFile.close()
driver.close()

