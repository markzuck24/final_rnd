function loadText() {


    var fr = new FileReader();
    fr.onload = function() {
        document.getElementById('output')
            .textContent = fr.result;
    }

    fr.readAsText(this.files[0]);

}
// function loadText() {
//     var xhr = new XMLHttpRequest();
//     xhr.open('GET', '/home/aditya/Desktop/aditya/output.txt', true);
//     xhr.onload = function() {
//         if (this.status == 200) {
//             document.getElementById('output').innerHTML = (this.responseText);
//         } else {
//             document.getElementById('output').innerHTML = (this.responseText);
//         }
//     }
//     xhr.send();
// }

// function loadText() {
//     var rawFile = new XMLHttpRequest();
//     rawFile.open("GET", file, false);
//     rawFile.onreadystatechange = function() {
//         if (rawFile.readyState === 4) {
//             if (rawFile.status === 200 || rawFile.status == 0) {
//                 var allText = rawFile.responseText;
//                 alert(allText);
//             }
//         }
//     }
//     rawFile.send(null);
// }


// function load() {
//     var openFile = function(event) {
//         var input = event.target;

//         var reader = new FileReader();
//         reader.onload = function() {
//             var text = reader.result;
//             var node = document.getElementById('output');
//             node.innerText = text;
//             console.log(reader.result.substring(0, 200));
//         };
//         reader.readAsText(input.files[0]);
//     };
// }



// function load() {
//     var input = document.getElementById("myFile");
//     var output = document.getElementById("output");


//     input.addEventListener("change", function() {
//         if (this.files && this.files[0]) {
//             var myFile = this.files[0];
//             var reader = new FileReader();

//             reader.addEventListener('load', function(e) {
//                 output.textContent = e.target.result;
//             });

//             reader.readAsBinaryString(myFile);
//         }
//     });
// }